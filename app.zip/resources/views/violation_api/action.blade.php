<div class="flex align-items-center violation-api-action">
    <button type="button" 
            class="btn btn-sm btn-info fetch-record" 
            data-id="{{ $id }}">
        Fetch Records
    </button>
</div>
