<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>


<div id="customLoader" class="custom-loader d-none">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div><?php /**PATH /var/www/html/civic_alert/resources/views/partials/dashboard/_body_loader.blade.php ENDPATH**/ ?>