
<footer class="footer">
    <div class="footer-body">
        <ul class="left-panel list-inline mb-0 p-0">
        </ul>
        <div class="right-panel">
            ©<script>document.write(new Date().getFullYear())</script>  <?php echo e(env('APP_NAME')); ?>, Made with
            <span class="text-gray">
                
            </span> by <a href="https://cartmarkaz.com/">Cart Markaz</a>.
        </div>
    </div>
</footer>

<?php /**PATH /var/www/html/civic_alert/resources/views/partials/dashboard/_body_footer.blade.php ENDPATH**/ ?>