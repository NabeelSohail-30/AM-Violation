<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div>
   <div class="row">
      <div class="col-sm-12">
         <div class="card">
            <div class="card-header d-flex justify-content-between">
               <div class="header-title">                 
                  <h4 class="card-title"><?php echo e($pageTitle ?? 'List'); ?></h4>
               </div>
                <div class="card-action">
                    <?php echo $headerAction ?? ''; ?>

                </div>
            </div>

            
            <?php if (! empty(trim($__env->yieldContent('filters')))): ?>
               <div class="mb-3 px-3">
                  <?php echo $__env->yieldContent('filters'); ?>
               </div>
            <?php endif; ?>

            <div class="card-body px-0">
               <div class="table-responsive">
                    <?php echo e($dataTable->table(['class' => 'table text-center table-striped w-100'],true)); ?>

               </div>
            </div>
         </div>
      </div>
   </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/civic_alert/resources/views/global/datatable.blade.php ENDPATH**/ ?>