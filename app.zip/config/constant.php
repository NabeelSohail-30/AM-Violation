<?php
return [
    'BOOLEAN_VARIABLE' => [
        'APP_DEBUG',
        'USE_PERSONAL_TOKEN',
        'EVANTO_LOGIN',
        'APP_SETUP'
    ],
];
