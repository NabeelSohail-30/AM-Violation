<x-app-layout :assets="$assets ?? []">
   <div class="container" style="margin-top: 81px;">
      <div class="text-center mb-5">
         <h2 class="fw-bold display-5" style="font-size: 40px;">Welcome to Your Dashboard</h2>
         <p class="text-muted mt-2">View All Violations | Fetch New Data | Account Settings</p>
      </div>

      <div class="row" style="display: flex; flex-direction: row; justify-content: center; align-items: center; gap:20px;">
         <!-- Recent Violation Fetches Card -->
         <div class="violation-card">
            <div>
               <div class="violation-header">
                  <img src="{{ asset('images/fetch-icon.png') }}" alt="Recent Violation Icon" width="48" height="48">
                  <h5 class="violation-title">Recent Violation Fetches</h5>
               </div>
               <p class="violation-desc">
                  Learn what your violation means and what to do next.
               </p>
            </div>
            <a href="{{ route('violation_api.index') }}" class="violation-btn">
               Explore
            </a>
         </div>
         <!-- Violation Records Card -->
         <div class="violation-card">
            <div>
               <div class="violation-header">
                  <img src="{{ asset('images/records-icon.png') }}" alt="Recent Violation Icon" width="48" height="48">
                  <h5 class="violation-title">Violation Records</h5>
               </div>
               <p class="violation-desc">
                  Learn what your violation means and what to do next.
               </p>
            </div>
            <a href="{{ route('violation_api.violation_records') }}" class="violation-btn">
               Explore
            </a>
         </div>

      </div>

      <style>
         .violation-card {
            width: 478px;
            height: 198px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            padding: 24px;
            background: #fff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
         }

         .violation-header {
            display: flex;
            align-items: center;
            gap: 10px;
         }

         .violation-icon {
            width: 36px;
            height: 36px;
            background-color: #ffecec;
            color: #e54848;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
         }

         .violation-title {
            font-weight: 600;
            font-size: 18px;
            color: #1f1f1f;
            margin: 0;
         }

         .violation-desc {
            color: #5c5c5c;
            font-size: 14px;
            margin: 12px 0 0;
         }

         .violation-btn {
            background-color: #1f1f1f;
            color: #fff;
            border: 1px solid black;
            border-radius: 6px;
            width: 100%;
            padding: 10px;
            font-weight: 500;
            transition: background 0.2s;
            text-decoration: none;
            text-align: center;
         }

         .violation-btn:hover {
            background-color: white;
            color: black;
            border: 1px solid black;
         }
      </style>

   </div>
</x-app-layout>