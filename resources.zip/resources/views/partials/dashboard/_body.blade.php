<div id="loading">
    @include('partials.dashboard._body_loader')
</div>
@include('partials.dashboard._body_sidebar')
<main class="main-content">
    <div class="position-relative">
        @include('partials.dashboard._body_header')
        @include('partials.dashboard.sub-header')
    </div>

    <div class="conatiner-fluid" style="margin: auto; padding: 0px 40px;">
        {{ $slot }}
    </div>

    <!-- @include('partials.dashboard._body_footer') -->
    <style>
        .footer {
            font-size: 14px;
            background: #fff;
            bottom: 0px;
            position: absolute;
            width: 86vw;
        }

        .footer .footer-body {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 0.5rem calc(var(--bs-gutter-x, 0.75rem) * 3);
            text-align: center !important;
            width: 100%;
        }

        .sidebar-default .navbar-nav .nav-item .nav-link:not(.disabled).active,
        .sidebar-default .navbar-nav .nav-item .nav-link:not(.disabled)[aria-expanded=true] {
            background-color: #d83d3d;
            box-shadow: 0 10px 20px -10px rgba(var(--bs-primary-rgb), 0.4);
        }

        .sidebar-default .navbar-nav .nav-item .nav-link:not(.disabled):hover:not(.active):not([aria-expanded=true]) {
            background-color: #e48181;
            color: #ffffff;
            box-shadow: none;
        }

        .fetch-records {
            background-color: black !important;
        }


        .btn.btn-info {
            color: var(--bs-white);
            background-color: black !important;
            border-color: none !important;
        }

        .btn.btn-info:hover {
            color: var(--bs-white);
            background-color: black !important;
            border-color: none !important;
        }

        .btn.btn-info:focus {
            color: var(--bs-white);
            background-color: black !important;
            border-color: none !important;
        }

        .btn.btn-info:active,
        .btn.btn-info.active {
            color: var(--bs-white);
            background-color: black !important;
            border-color: none !important;
        }

        .page-item.active .page-link {
            color: var(--bs-white);
            background-color: #000;
            border-color: #000;
        }

        .page-item .page-link {
            border-color: var(--bs-primary-tint-80);
            color: #c03221;
        }

        .btn.btn-primary {
            color: var(--bs-white);
            background-color: #c03221;
            border-color: #c03221;
        }

        .btn.btn-primary:hover {
            color: var(--bs-white);
            background-color: #c03221;
            border-color: #c03221;
        }

        .btn.btn-primary:focus {
            color: var(--bs-white);
            background-color: #c03221;
            border-color: #c03221;
        }

        .btn-check:focus+.btn-success,
        .btn-success:focus {
            color: #fff;
            background-color: #000;
            border-color: #000;
            box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0), 0 0 0 0rem rgba(60, 174, 109, 0.5);
        }

        .btn-success {
            color: #fff;
            background-color: #000;
            border-color: #000;
            box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0), 0 0 0 0rem rgba(60, 174, 109, 0.5);
        }

        .btn-success:hover {
            color: var(--bs-white);
            background-color: #c03221;
            border-color: #c03221;
        }
    </style>
</main>

@include('partials.components.setting-offcanvas')
@include('partials.dashboard._scripts')
@include('partials.dashboard._app_toast')
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formTitle">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="main_form"></div>
            </div>
        </div>
    </div>
</div>