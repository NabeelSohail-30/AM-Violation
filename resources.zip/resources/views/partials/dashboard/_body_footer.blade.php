
<footer class="footer">
    <div class="footer-body text-center">
            ©<script>document.write(new Date().getFullYear())</script>  {{env('APP_NAME')}}
    </div>
</footer>

