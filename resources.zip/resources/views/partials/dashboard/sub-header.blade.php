<div>
    <!-- <div class="container-fluid iq-container">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex justify-content-between align-items-center flex-wrap">
                    <div>
                        <h1>Stop Paying Surprise Parking Fines</h1>
                        <p>Our smart system monitors NYC violations 24/7 and sends you instant alerts. It’s fast, easy, and 100% free to get started.</p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div> -->
    <div>
        <img src="{{asset('images/dashboard.png')}}" alt="header" style="
    display: flex;
    justify-content: center;
    align-items: center;
    margin: auto;
    margin: 20px auto;
">
    </div>
</div>